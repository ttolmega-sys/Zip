import { useChangelog } from '../../../../../shared/changelog'
import { DEFAULTS } from '../../index'
import type { HideCallButtonsStorage } from '../../index'
import * as components from '@revenge-mod/components'
import { Design } from '@revenge-mod/discord/design'
import * as ReactNative from 'react-native'

export default function Settings({
	api,
}: {
	api: RevengePluginStartApi<HideCallButtonsStorage>
}) {
	// The changelog icon at the top right, and "What's new" once after an update.
	useChangelog()
	// Read per-render, never at module scope -- see docs/porting-rules.md rule 1.
	const { Page } = components
	const { ScrollView } = ReactNative
	const { Stack, TableRowGroup, TableSwitchRow } = Design
	const { TableRowAssetIcon } = components

	const s = api.jsonStorage.use() ?? DEFAULTS
	const set = (patch: Partial<HideCallButtonsStorage>) =>
		api.jsonStorage.set(patch)

	return (
		<Page>
			<ScrollView>
				<Stack spacing={24}>
					<TableRowGroup title="User profile">
						<TableSwitchRow
							label="Hide call button"
							icon={<TableRowAssetIcon name="PhoneCallIcon" />}
							value={!!s.upHideVoiceButton}
							onValueChange={v => set({ upHideVoiceButton: v })}
						/>
						<TableSwitchRow
							label="Hide video button"
							icon={<TableRowAssetIcon name="VideoIcon" />}
							value={!!s.upHideVideoButton}
							onValueChange={v => set({ upHideVideoButton: v })}
						/>
					</TableRowGroup>
					<TableRowGroup title="DMs">
						<TableSwitchRow
							label="Hide call button"
							icon={<TableRowAssetIcon name="PhoneCallIcon" />}
							value={!!s.dmHideCallButton}
							onValueChange={v => set({ dmHideCallButton: v })}
						/>
						<TableSwitchRow
							label="Hide video button"
							icon={<TableRowAssetIcon name="VideoIcon" />}
							value={!!s.dmHideVideoButton}
							onValueChange={v => set({ dmHideVideoButton: v })}
						/>
					</TableRowGroup>
					<TableRowGroup title="Friends list">
						<TableSwitchRow
							label="Hide call button"
							icon={<TableRowAssetIcon name="PhoneCallIcon" />}
							value={!!s.friendsHideCallButton}
							onValueChange={v => set({ friendsHideCallButton: v })}
						/>
					</TableRowGroup>
					<TableRowGroup title="Voice channels">
						<TableSwitchRow
							label="Hide video button"
							icon={<TableRowAssetIcon name="VideoIcon" />}
							value={!!s.hideVCVideoButton}
							onValueChange={v => set({ hideVCVideoButton: v })}
						/>
					</TableRowGroup>
				</Stack>
			</ScrollView>
		</Page>
	)
}
