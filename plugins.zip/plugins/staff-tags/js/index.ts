import { DEFAULTS, setStorage } from "./lib/state"
import patchChat from "./patches/chat"
import patchDetails from "./patches/details"
import patchName from "./patches/name"
import patchTag from "./patches/tag"
import Settings from "./ui/pages/Settings"
import { registerPages } from "./ui/routes"
import type { StaffTagsStorage } from "./types"
import { CHANGELOG } from "./changelog"
import { setupChangelog } from "../../../shared/changelog"
import { reportError, setReporter } from "../../../shared/report"

export { DEFAULTS }
export type { StaffTagsStorage }

export default plugin<{ jsonStorage: StaffTagsStorage }>({
	jsonStorage: {
		load: true,
		default: DEFAULTS,
	},
	start({ cleanup, jsonStorage, plugin }) {
		// Errors go to Revenge's plugin error list (shared/report.ts), not the log.
		setReporter(plugin)
		cleanup(() => setReporter(undefined))

		// Enabling a plugin mid-session leaves its hooks half-applied -- Discord modules it patches
		// may already be initialized and its settings routes are registered too late for the
		// settings screen. Ask for a reload instead of running in a state we cannot verify.
		if (plugin.startedLate) {
			plugin.requireReload()
			return
		}

		// The changelog: clock icon on the settings page, "What's new" after an update.
		cleanup(setupChangelog({ plugin, jsonStorage }, CHANGELOG))

		setStorage(jsonStorage)

		try {
			cleanup(registerPages())
		} catch (error) {
			reportError("[StaffTags] failed to register settings pages:", error)
		}

		// Apply each surface independently -- a single moved Discord module must disable
		// one surface, not make the whole plugin impossible to enable.
		const apply = (name: string, patch: () => () => void) => {
			try {
				cleanup(patch())
			} catch (error) {
				reportError(`[StaffTags] failed to apply ${name} patch:`, error)
			}
		}

		const installTimer = setTimeout(() => {
			apply("chat", () => patchChat(jsonStorage))
			apply("tag", patchTag)
			apply("name", () => patchName(jsonStorage))
			apply("details", () => patchDetails(jsonStorage))
		}, 0)
		cleanup(() => clearTimeout(installTimer))
	},
	// Unpatching cannot put back everything a hook changed once Discord has rendered with it.
	stop(api) {
		api.plugin.requireReload()
	},
	SettingsComponent: Settings,
})
