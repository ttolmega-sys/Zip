import { DEFAULT_BACKUP_PATH, DEFAULTS } from '../../defaults'
import { fillWithFakeEntries } from '../../lib/debug'
import { dumpMessageStore, dumpRoutingModules, inspectCurrentChannel, inspectMessageInstance, isProbeRunning, probeNavigationModules, setProbeRunning } from '../../lib/probe'
import { getSettingsStorage } from '../state'
import { rowIcon } from '../icon'
import { showToast } from '../../../../../shared/toast'
import { useBottomPadding } from '../safeArea'
import type { GhostLogSettings } from '../../types'
import * as components from '@revenge-mod/components'
import { Design } from '@revenge-mod/discord/design'
import * as react from '@revenge-mod/react'
import * as ReactNative from 'react-native'

export default function Debug() {
	const { Page } = components
	const { React } = react
	const { ScrollView, Alert } = ReactNative
	const { Stack, TableRowGroup, TableRow, TableSwitchRow } = Design

	const storage = getSettingsStorage()
	const s = { ...DEFAULTS, ...(storage?.use() ?? {}) }
	const set = (patch: Partial<GhostLogSettings>) => storage?.set(patch)

	const [probing, setProbing] = React.useState(isProbeRunning('messageLoad'))
	const [watching, setWatching] = React.useState(isProbeRunning('getMessages'))
	const backupPath = s.backupFilePath?.trim() || DEFAULT_BACKUP_PATH

	const toast = (content: string) => showToast(content, 'ghost-log-native-beta-debug')

	const seedFake = () => {
		Alert.alert(
			'Fill with fake deleted messages',
			'Add 200 fake entries across fake servers, users and channels. For UI testing.',
			[
				{ text: 'Cancel', style: 'cancel' },
				{
					text: 'Fill 200',
					onPress: () => {
						void (async () => {
							const added = await fillWithFakeEntries(200)
							toast(`Added ${added} fake deleted messages.`)
						})()
					},
				},
			],
		)
	}

	// Both probes live in lib/probe's registry, which the plugin's cleanup tears down. Keeping the
	// stop handles here meant a disabled plugin left its hooks installed.
	const toggleProbe = (on: boolean) => {
		const running = setProbeRunning('messageLoad', on)
		setProbing(running)
		toast(running ? 'Probe on — switch channels, then check logcat.' : 'Probe off.')
	}

	const toggleGetMessages = (on: boolean) => {
		const running = setProbeRunning('getMessages', on)
		setWatching(running)
		toast(running ? 'Watching getMessages — open a channel, then check logcat.' : 'getMessages watch off.')
	}

	return (
		<Page>
			<ScrollView contentContainerStyle={{ paddingBottom: useBottomPadding() }}>
				<Stack spacing={24}>
					<TableRowGroup title="Testing" hasIcons>
						<TableSwitchRow
							label="Count my own messages"
							subLabel="For testing only: lets you delete your own message and verify capture."
							icon={rowIcon('UserIcon')}
							value={!!s.countOwnMessages}
							onValueChange={v => set({ countOwnMessages: v })}
						/>
						<TableRow
							label="Fill log with 200 fake entries"
							subLabel="For UI testing: multiple servers, users, channels and attachments. Adds to the current log."
							icon={rowIcon('BugIcon', 'ic_debug')}
							onPress={seedFake}
						/>
						<TableRow
							label="Backup target path"
							subLabel={backupPath}
							icon={rowIcon('PinIcon', 'ic_pin')}
						/>
					</TableRowGroup>

					<TableRowGroup title="Restore research" hasIcons>
						<TableSwitchRow
							label="Message-load probe"
							subLabel="Logs message/channel-load events and the channel's MessageStore shape to logcat. Shapes and counts only."
							icon={rowIcon('SearchIcon', 'MagnifyingGlassIcon', 'ic_search')}
							value={probing}
							onValueChange={toggleProbe}
						/>
						<TableSwitchRow
							label="Watch getMessages"
							subLabel="Logs what getMessages returns when a channel renders — the render-layer injection point."
							icon={rowIcon('EyeIcon')}
							value={watching}
							onValueChange={toggleGetMessages}
						/>
						<TableRow
							label="Inspect current channel"
							subLabel="Dump the open channel's cached MessageStore structure to logcat."
							icon={rowIcon('ListIcon', 'ic_list')}
							onPress={() => toast(inspectCurrentChannel())}
						/>
						<TableRow
							label="Dump MessageStore methods"
							subLabel="Lists every method/property on MessageStore to logcat."
							icon={rowIcon('ListBulletsIcon', 'ic_list')}
							onPress={() => toast(dumpMessageStore())}
						/>
						<TableRow
							label="Inspect a real message"
							subLabel="Logs a real message's constructor, field types, and methods."
							icon={rowIcon('SearchIcon', 'ic_search')}
							onPress={() => toast(inspectMessageInstance())}
						/>
						<TableRow
							label="Probe navigation modules"
							subLabel="Sweeps for a module that can open/jump to a message. Logs candidates to logcat."
							icon={rowIcon('SearchIcon', 'ic_search')}
							onPress={() => toast(probeNavigationModules())}
						/>
						<TableRow
							label="Dump routing modules"
							subLabel="Logs the full key list of the transitionToGuild/selectPrivateChannel/jumpToMessage modules."
							icon={rowIcon('SearchIcon', 'ic_search')}
							onPress={() => toast(dumpRoutingModules())}
						/>
					</TableRowGroup>
				</Stack>
			</ScrollView>
		</Page>
	)
}
