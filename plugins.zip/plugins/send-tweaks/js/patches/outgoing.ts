/**
 * Rewriting a message's text on its way out -- both new messages and edits.
 *
 * ## A plain wrapper, not a patcher hook
 *
 * `sendMessage` and `editMessage` are `instead`-hooked by other plugins (fake-nitro, Zipline,
 * message-tweaks, and our own Second Thoughts). A patcher `before` registered ahead of two of those
 * made them recurse forever, and edits failed to save for anyone with that combination. So both
 * methods are wrapped with a plain function instead; `lib/wrap.ts` explains why that cannot recurse.
 *
 * The cost: when Second Thoughts' `instead` is added after this wrapper, it judges the draft before
 * links are cleaned rather than after. Tracking parameters and your rules do not change what it looks
 * for, so the verdict is the same.
 *
 * ## Only the text is touched
 *
 * The message object's `content` is replaced and nothing else. Attachments, stickers, reply
 * references and allowed mentions pass through exactly as Discord built them. A hook that returns
 * without changing anything leaves the send identical to one without this plugin installed.
 *
 * The rewrite changes the message object in place and never throws out of the wrapper, so a failure
 * sends the message exactly as typed.
 *
 * ## Silent messages are new messages only
 *
 * With Silent messages on, a new message gets Discord's own `@silent ` prefix after every other change
 * (`lib/silent.ts`), so your rules never see it and it is always the very first thing in the text.
 * Edits are left alone: flags cannot change after sending, and an edit would keep the literal text.
 *
 * ## Restyled messages
 *
 * When Send in the Preview carries a restyled message (`lib/styles.ts`), the styled text replaces
 * the content first, and the usual steps then run over it -- except Polish wording, which would
 * capitalise uwu. "Send unchanged" also throws away a waiting restyle.
 *
 * ## Edits are cleaned when the edit box opens, not only when it is saved
 *
 * Discord skips `editMessage` entirely when the edited text is identical to the original, so a
 * hook there alone never ran on "open edit, save" -- the obvious way to clean an old message's
 * link. Cleaning the draft carried by `MESSAGE_START_EDIT` fixes that: the edit box opens with
 * the cleaned text, which now differs from the original, so saving goes through. You also see
 * the result before saving, and can cancel. The `editMessage` hook stays for text typed or
 * pasted into the box afterwards.
 *
 * A Flux patch rather than a hook on `startEditMessage`: that export and
 * `startEditMessageRecord` both end in this one event, and the latter may call the former
 * without going through the export. Returning nothing from a Flux patch blocks the event, so
 * every path returns a payload.
 */

import { whenModule } from '../lib/finder'
import { wrapMethod } from '../lib/wrap'
import { debug, settings, TAG } from '../lib/state'
import { transform, type TransformOptions } from '../lib/transform'
import { clearRestyle, takeRestyle } from '../lib/styles'
import { type OneOff, takeNextSend } from '../lib/nextSend'
import { makeSilent } from '../lib/silent'
import { withSendContext } from '../lib/greetings'
import { withSendRandom } from '../lib/random'
import { onFluxEventDispatched } from '@revenge-mod/discord/flux'
import { reportError } from '../../../../shared/report'

const DEBUG: boolean = false

const status = {
	installed: false,
	moduleId: -1,
	sends: 0,
	edits: 0,
	/** Edit boxes opened with already-cleaned text. */
	drafts: 0,
	/** New messages sent restyled from the Preview. */
	restyled: 0,
	cleaned: 0,
	replaced: 0,
	/** Links changed by a link rule. */
	rewritten: 0,
	/** New messages sent with @silent added. */
	silenced: 0,
	/** Messages sent unchanged from the send button's long-press sheet. */
	untouched: 0,
}

export function outgoingStatus() {
	return { ...status }
}

function rewrite(message: any, kind: 'send' | 'edit' | 'draft', options?: TransformOptions) {
	if (!message || typeof message.content !== 'string' || !message.content)
		return

	const result = transform(message.content, options)
	if (result.text === message.content) return

	message.content = result.text
	status.cleaned += result.cleaned
	status.replaced += result.replaced
	status.rewritten += result.rewritten
	if (kind === 'send') status.sends++
	else if (kind === 'edit') status.edits++
	else status.drafts++
	debug(
		`${kind}: ${result.cleaned} tracking param(s) removed, ${result.rewritten} link(s) rewritten, ${result.replaced} rule(s) applied`,
	)
}

/** Last, after `rewrite`: see "Silent messages are new messages only" above. */
function silence(message: any, once?: OneOff) {
	const wanted = once === 'silent' ? true : once === 'loud' ? false : settings().silentMessages
	if (!wanted) return
	if (!message || typeof message.content !== 'string') return
	const silent = makeSilent(message.content)
	if (silent === message.content) return
	message.content = silent
	status.silenced++
	debug('send: @silent added')
}

export default function patchOutgoing(): () => void {
	const patches: Array<() => void> = []

	patches.push(
		onFluxEventDispatched(
			'MESSAGE_START_EDIT',
			(payload: any) => {
				try {
					if (!settings().applyToEdits) return payload
					// A copy, so nothing else holding the original payload sees it change.
					const draft = { ...payload }
					withSendContext({ channelId: payload.channelId ?? payload.channel_id }, () => rewrite(draft, 'draft'))
					return draft
				} catch (error) {
					reportError(`${TAG} edit draft rewrite failed:`, error)
					return payload
				}
			},
		),
	)

	patches.push(
		whenModule(
			['sendMessage', 'editMessage', 'startEditMessage'],
			(host, id) => {
				// sendMessage(channelId, message, ...)
				patches.push(
					wrapMethod(host, 'sendMessage', args => {
						// Taken first and always, so a one-off from the long-press sheet is used up by
						// this send and never carried to the next one.
						const once = takeNextSend()
						if (once === 'raw') {
							clearRestyle()
							status.untouched++
							debug('send: sent unchanged, as asked from the send button')
							return
						}
						// Before anything else, so every step below sees the styled text.
						let options: TransformOptions | undefined
						const message = args[1]
						if (message && typeof message.content === 'string') {
							const styled = takeRestyle(message.content)
							if (styled !== undefined) {
								message.content = styled
								options = { polish: false }
								status.restyled++
								debug('send: restyled from the preview')
							}
						}
						// The channel and reply target, for greeting placeholders (lib/greetings.ts).
						const reference = args.find((arg: any) => arg?.messageReference)?.messageReference
						withSendContext(
							{ channelId: args[0], replyToId: reference?.message_id ?? reference?.messageId },
							() => withSendRandom(args[1]?.content ?? '', () => rewrite(args[1], 'send', options)),
						)
						silence(args[1], once)
					}),
				)

				// editMessage(channelId, messageId, { content })
				patches.push(
					wrapMethod(host, 'editMessage', args => {
						if (settings().applyToEdits) withSendContext({ channelId: args[0] }, () => rewrite(args[2], 'edit'))
					}),
				)

				status.installed = true
				status.moduleId = id
				// Log the outcome, not the attempt -- porting rule 3.
				if (DEBUG) console.log(`${TAG} rewriting outgoing messages on module ${id}`)
			},
		),
	)

	return () => {
		status.installed = false
		for (const unpatch of patches.reverse()) {
			try {
				unpatch()
			} catch {
				/* already gone */
			}
		}
	}
}
