@file:JvmName("AiCore")

package com.bleelblep.aicore

import android.app.Activity
import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import io.github.revenge.plugins.PluginScope
import io.github.revenge.plugins.plugin
import io.github.revenge.xposed.api.callJSMethod
import io.github.revenge.xposed.api.registerNativeAsyncMethod
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.security.KeyStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * AI Core's native half: the only place the API key exists in the clear.
 *
 * ## Why this is native at all
 *
 * Every Revenge plugin shares one JS runtime with full access to it. In JS the key could be read
 * from `storage.json` with `fs`, from memory, or from the `Authorization` header by anyone who
 * patched `fetch`. None of that reaches here:
 *
 * - The key is typed into a native Android dialog ([promptForKey]), never a React input, so it
 *   never passes through JS -- not through `callNativeMethod`, not through a TextInput a plugin
 *   could hook.
 * - At rest it is AES-GCM encrypted under an Android Keystore key, which cannot be exported from
 *   the device. `storageDir` is shared with JS, so JS can see the ciphertext; it cannot open it.
 * - The request is made here, with the header added here. JS hands over the messages and gets
 *   back the reply text and token counts. Nothing else crosses.
 *
 * ## The key is bound to the endpoint it was entered for
 *
 * Otherwise any plugin could point the base URL at its own server and have this code post the
 * key there. The endpoint is stored beside the key, shown in the entry dialog, and is the only
 * place the key is ever sent. Redirects are not followed, because a redirect carries the header
 * to wherever it points.
 *
 * ## What this does not stop
 *
 * Any plugin can call these methods, and the caller cannot be verified -- so another plugin can
 * *use* the key, it just cannot *see* it. The daily cap is enforced here for that reason, and
 * raising it or resetting the count needs a native confirmation. A plugin that saved the
 * encrypted usage file and restored it across a restart could roll the count back; the spending
 * limit on the key itself is the backstop for that. Native plugins run in the same process and
 * are outside this model entirely.
 */

private const val KEYSTORE = "AndroidKeyStore"
private const val KEY_ALIAS = "bleelblep.ai-core.vault.v1"
private const val VAULT_FILE = "vault.v1.enc"
private const val USAGE_FILE = "usage.v1.enc"
private const val MAX_CAP = 1000

/**
 * Ceilings on one request, whoever asks. A caller sets the reply length and sends the prompt, so
 * without these forty calls a day could still run up a large bill. The adapters below raise small
 * allowances to a 2048 floor for thinking models; nothing goes past [MAX_OUTPUT_TOKENS].
 */
// Shift asks for 8192 for a whole theme; nothing else here asks for more than 4096.
private const val MAX_OUTPUT_TOKENS = 8192
/** About 50,000 tokens of prompt: a long Catch Up fits, a pasted book does not. */
private const val MAX_PROMPT_CHARS = 200_000
private const val MAX_MESSAGES = 200

/** Providers AI Core knows. A key dialog for any other address says so, in case it isn't the user's. */
private val KNOWN_HOSTS = setOf(
	"api.anthropic.com", "api.openai.com", "api.deepseek.com", "openrouter.ai", "api.groq.com",
	"integrate.api.nvidia.com", "api.mistral.ai", "generativelanguage.googleapis.com", "api.together.xyz",
)

// --- Keystore-backed AES-GCM -------------------------------------------------

private fun keystoreKey(): SecretKey {
	val store = KeyStore.getInstance(KEYSTORE).apply { load(null) }
	(store.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
	val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
	generator.init(
		KeyGenParameterSpec.Builder(
			KEY_ALIAS,
			KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
		)
			.setBlockModes(KeyProperties.BLOCK_MODE_GCM)
			.setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
			.setKeySize(256)
			.build(),
	)
	return generator.generateKey()
}

private fun seal(plain: String): String {
	val cipher = Cipher.getInstance("AES/GCM/NoPadding")
	// Keystore keys require the cipher to choose the IV.
	cipher.init(Cipher.ENCRYPT_MODE, keystoreKey())
	val ct = cipher.doFinal(plain.toByteArray(Charsets.UTF_8))
	return JSONObject()
		.put("v", 1)
		.put("iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP))
		.put("ct", Base64.encodeToString(ct, Base64.NO_WRAP))
		.toString()
}

/** Null when missing, tampered with, or sealed under a Keystore key that no longer exists. */
private fun open(raw: String): String? = runCatching {
	val obj = JSONObject(raw)
	val cipher = Cipher.getInstance("AES/GCM/NoPadding")
	cipher.init(
		Cipher.DECRYPT_MODE,
		keystoreKey(),
		GCMParameterSpec(128, Base64.decode(obj.getString("iv"), Base64.NO_WRAP)),
	)
	String(cipher.doFinal(Base64.decode(obj.getString("ct"), Base64.NO_WRAP)), Charsets.UTF_8)
}.getOrNull()

// --- endpoint rules ------------------------------------------------------------

/**
 * `https://` anywhere, plain `http://` only to this device or a private network (a local
 * llama.cpp). Returns the normalized base URL, or null if the key must not be sent there.
 */
private fun normalizeEndpoint(raw: String): String? = runCatching {
	val trimmed = raw.trim().trimEnd('/')
	val uri = URI(trimmed)
	val host = uri.host?.lowercase() ?: return null
	if (uri.userInfo != null) return null
	when (uri.scheme?.lowercase()) {
		"https" -> trimmed
		"http" -> if (isPrivateHost(host)) trimmed else null
		else -> null
	}
}.getOrNull()

private fun isPrivateHost(host: String): Boolean {
	if (host == "localhost" || host == "127.0.0.1" || host == "::1") return true
	// All four parts must be numbers: dropping the words let "192.168.1.1.example.com" pass as a
	// home address, and the key could then go there over plain http.
	val labels = host.split('.')
	if (labels.size != 4) return false
	val parts = labels.map { it.toIntOrNull() ?: return false }
	if (parts.any { it !in 0..255 }) return false
	return parts[0] == 10 ||
		(parts[0] == 192 && parts[1] == 168) ||
		(parts[0] == 172 && parts[1] in 16..31)
}

private fun hostOf(endpoint: String): String = runCatching { URI(endpoint).host }.getOrNull() ?: endpoint

// --- Anthropic ---------------------------------------------------------------------

/**
 * A key bound to Anthropic's API is spoken to in Anthropic's own Messages API rather than the
 * OpenAI chat-completions shape every other provider here accepts. Decided by the endpoint the key
 * is bound to, never by anything the caller sends.
 */
private fun isAnthropic(endpoint: String): Boolean =
	runCatching { URI(endpoint).host.equals("api.anthropic.com", ignoreCase = true) }.getOrDefault(false)

/** Models that take `output_config.effort`; older and Haiku models reject it. */
private val EFFORT_MODELS = Regex("^claude-(fable-5|mythos-5|opus-5|opus-4-[678]|sonnet-5|sonnet-4-6)")

/** Models whose declined requests Anthropic can re-run on its recommended fallback. */
private val DEFAULT_FALLBACK_MODELS = Regex("^claude-(opus-5|fable-5)")

private const val FALLBACK_BETA = "server-side-fallback-2026-07-01"

// --- OpenAI --------------------------------------------------------------------------

private fun isOpenAi(endpoint: String): Boolean =
	runCatching { URI(endpoint).host.equals("api.openai.com", ignoreCase = true) }.getOrDefault(false)

/** Reasoning models (GPT-5, o-series, and open reasoning models like gpt-oss): no custom temperature, and reasoning spends tokens. */
private val REASONING_MODELS = Regex("^(gpt-5|o[0-9]|openai/gpt-oss|gpt-oss)", RegexOption.IGNORE_CASE)

/**
 * OpenAI and Groq take `max_completion_tokens` (every chat model accepts it; reasoning models reject the
 * old `max_tokens`). Reasoning models also reject a custom temperature, and their thinking spends
 * from the same allowance, so they get a floor and low effort, as Anthropic's models do.
 */
private fun adaptForOpenAiOrGroq(payload: JSONObject, endpoint: String) {
	val model = payload.optString("model")
	val requested = if (payload.has("max_tokens")) payload.optInt("max_tokens", 256) else 256
	val host = runCatching { URI(endpoint).host }.getOrNull()?.lowercase() ?: ""
	val isGroqOrOpenAi = host.contains("openai.com") || host.contains("groq.com")

	if (isGroqOrOpenAi || REASONING_MODELS.containsMatchIn(model)) {
		payload.remove("max_tokens")
		if (REASONING_MODELS.containsMatchIn(model)) {
			payload.remove("temperature")
			payload.put("max_completion_tokens", maxOf(requested, 2048))
			if (host.contains("openai.com")) {
				payload.put("reasoning_effort", "low")
			}
		} else {
			payload.put("max_completion_tokens", requested)
		}
	}
}

// --- NVIDIA ---------------------------------------------------------------------------

private fun isNvidia(endpoint: String): Boolean =
	runCatching { URI(endpoint).host.equals("integrate.api.nvidia.com", ignoreCase = true) }.getOrDefault(false)

/**
 * NVIDIA's Nemotron models think before answering, and the thinking spends from max_tokens: at
 * TL;DR's 160 or a verdict's 20 they spend it all and return no content (checked on device
 * 2026-10-13 with nemotron-3.5-lightning; "/no_think" in the prompt changed nothing). So thinking
 * is switched off through the chat template, which NVIDIA's API passes to the model, and the
 * allowance gets a floor in case a model thinks anyway. Models without a thinking switch ignore it.
 */
private fun adaptForNvidia(payload: JSONObject) {
	val requested = if (payload.has("max_tokens")) payload.optInt("max_tokens", 256) else 256
	payload.put("max_tokens", maxOf(requested, 2048))
	payload.put("chat_template_kwargs", JSONObject().put("enable_thinking", false))
}

/** Reasoning that leaked into the answer as a <think> block. */
private val THINK_BLOCK = Regex("""^\s*<think>[\s\S]*?</think>\s*""")

/**
 * Translates the OpenAI-shaped body AI Core's JS sends into a Messages API request:
 * - system messages become the top-level `system`, and consecutive turns from one role are merged
 *   (the API wants user and assistant to alternate, starting with the user);
 * - no `temperature`: current models reject sampling parameters;
 * - `max_tokens` has a floor, because thinking (on by default on current models) spends from the
 *   same allowance and a small cap could leave nothing for the answer. Only tokens used are billed;
 * - low effort where the model takes it: these are short checks and summaries;
 * - JSON mode becomes an instruction, since the API has no schema-less JSON mode;
 * - `fallbacks: "default"` where supported, so a declined request is retried server-side.
 */
private fun anthropicPayload(body: JSONObject): JSONObject {
	val model = body.optString("model")
	val system = StringBuilder()
	val messages = JSONArray()
	val input = body.optJSONArray("messages") ?: JSONArray()
	for (i in 0 until input.length()) {
		val message = input.optJSONObject(i) ?: continue
		val content = message.optString("content")
		if (message.optString("role") == "system") {
			if (system.isNotEmpty()) system.append("\n\n")
			system.append(content)
			continue
		}
		val role = if (message.optString("role") == "assistant") "assistant" else "user"
		val last = if (messages.length() > 0) messages.getJSONObject(messages.length() - 1) else null
		if (last != null && last.optString("role") == role) {
			last.put("content", last.optString("content") + "\n\n" + content)
		} else {
			if (last == null && role == "assistant") messages.put(JSONObject().put("role", "user").put("content", "Continue."))
			messages.put(JSONObject().put("role", role).put("content", content))
		}
	}
	if (body.optJSONObject("response_format")?.optString("type") == "json_object") {
		if (system.isNotEmpty()) system.append("\n\n")
		system.append("Reply with a single JSON object and nothing else.")
	}
	val payload = JSONObject()
		.put("model", model)
		.put("max_tokens", maxOf(body.optInt("max_tokens", 256), 2048))
		.put("messages", messages)
	if (system.isNotEmpty()) payload.put("system", system.toString())
	if (EFFORT_MODELS.containsMatchIn(model)) payload.put("output_config", JSONObject().put("effort", "low"))
	if (DEFAULT_FALLBACK_MODELS.containsMatchIn(model)) payload.put("fallbacks", "default")
	return payload
}

// --- native dialogs ------------------------------------------------------------

/**
 * Runs [block] on the UI thread with a live activity. Everything inside is guarded: an exception on
 * the UI thread is fatal to the whole app, and `Dialog.show()` throws `BadTokenException`
 * when the activity is being torn down between the check and the call. [onFailure] lets the caller
 * resolve its pending result instead of waiting out the full timeout.
 */
private fun PluginScope.onActivity(onFailure: () -> Unit, block: (Activity) -> Unit) {
	withAppActivity { activity ->
		activity.runOnUiThread {
			try {
				if (activity.isFinishing || activity.isDestroyed) onFailure() else block(activity)
			} catch (error: Throwable) {
				log.e("AI Core dialog failed", error)
				onFailure()
			}
		}
	}
}

private fun dp(activity: Activity, value: Int): Int =
	(value * activity.resources.displayMetrics.density).toInt()

/**
 * The colours of whichever Discord theme is active (Ash, Dark, Onyx, Light), read from the app's
 * own `ThemeManager` so the dialogs match without guessing. Reflection because the plugin is not
 * compiled against Discord; any miss falls back to the stock dark palette rather than failing.
 */
private class Palette(
	val surface: Int,
	val heading: Int,
	val text: Int,
	val muted: Int,
	val inputBackground: Int,
	val inputBorder: Int,
	val inputBorderActive: Int,
	val primaryBackground: Int,
	val primaryText: Int,
	val criticalBackground: Int,
	val criticalText: Int,
	val secondaryBackground: Int,
	val secondaryText: Int,
)

private fun discordPalette(activity: Activity): Palette {
	val theme = runCatching {
		val manager = Class.forName("com.discord.theme.ThemeManager", true, activity.classLoader)
		manager.getMethod("getEffectiveTheme").invoke(manager.getField("INSTANCE").get(null))
	}.getOrNull()
	// Discord 352.2+ (R8-minified): no ThemeManager by name, so colours come from resources.
	val minified = if (theme == null) MinifiedTheme.current() else null
	fun color(getter: String, fallback: Long, vararg resources: String): Int =
		runCatching { theme!!.javaClass.getMethod(getter).invoke(theme) as Int }.getOrNull()
			?: minified?.let { MinifiedTheme.color(activity, it, *resources) }
			?: fallback.toInt()
	return Palette(
		surface = color("getBackgroundSurfaceHigh", 0xFF2B2D31, "neutral_64", "neutral_79", "neutral_1", "neutral_96"),
		heading = color("getMobileTextHeadingPrimary", 0xFFF2F3F5, "neutral_1", "neutral_2", "neutral_76", "neutral_10"),
		text = color("getTextDefault", 0xFFDBDEE1, "neutral_4", "neutral_5", "neutral_72", "neutral_12"),
		muted = color("getTextMuted", 0xFF949BA4, "neutral_23", "neutral_29", "neutral_41", "neutral_35"),
		inputBackground = color(
			"getInputBackgroundDefault", 0xFF1E1F22, "input_background_default_ash", "input_background_default_dark",
			"input_background_default_light", "input_background_default_onyx",
		),
		inputBorder = color(
			"getInputBorderDefault", 0x33FFFFFF, "input_border_default_ash", "input_border_default_dark",
			"input_border_default_light", "input_border_default_onyx",
		),
		inputBorderActive = color("getInputBorderActive", 0xFF5865F2, "blurple_50"),
		primaryBackground = color("getControlPrimaryBackgroundDefault", 0xFF5865F2, "blurple_50"),
		primaryText = color("getControlPrimaryTextDefault", 0xFFFFFFFF, "neutral_1"),
		criticalBackground = color("getControlCriticalPrimaryBackgroundDefault", 0xFFDA373C, "red_new_50"),
		criticalText = color("getControlCriticalPrimaryTextDefault", 0xFFFFFFFF, "neutral_1"),
		secondaryBackground = color(
			"getControlSecondaryBackgroundDefault", 0xFF4E5058, "control_secondary_background_default_ash",
			"control_secondary_background_default_dark", "control_secondary_background_default_light",
			"control_secondary_background_default_onyx",
		),
		secondaryText = color("getControlSecondaryTextDefault", 0xFFFFFFFF, "neutral_1", "neutral_2", "neutral_76", "neutral_10"),
	)
}

private val fonts = mutableMapOf<String, Typeface?>()

/** gg sans from Discord's own assets; null (system font) if a build ever drops the file. */
private fun ggSans(activity: Activity, weight: String): Typeface? = fonts.getOrPut(weight) {
	runCatching { Typeface.createFromAsset(activity.assets, "fonts/ggsans-$weight.ttf") }.getOrNull()
}

private class DialogInput(
	val label: String? = null,
	val hint: String = "",
	val password: Boolean = false,
	/**
	 * When set, the action stays disabled until exactly this is typed, capitals included. Surrounding
	 * spaces are ignored, since a keyboard can add one after a word.
	 */
	val required: String? = null,
)

/**
 * A native dialog laid out like Discord's own alert: centred heading and body, a filled input,
 * and full-width pill buttons with the action above Cancel. Resolves the typed text (or "" with
 * no input) on the action, null on cancel, dismissal or timeout.
 *
 * Deliberately not a JS modal: the confirmations here are what stop another plugin raising the
 * cap on its own, and anything drawn in JS another plugin could draw, or skip, too.
 */
private suspend fun PluginScope.discordDialog(
	title: String,
	message: String,
	action: String,
	destructive: Boolean = false,
	input: DialogInput? = null,
	timeoutMs: Long = 2 * 60_000L,
): String? {
	val result = CompletableDeferred<String?>()
	onActivity({ result.complete(null) }) { activity ->
		val p = discordPalette(activity)
		fun px(value: Int) = dp(activity, value)
		fun shape(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
			setColor(color)
			cornerRadius = px(radius).toFloat()
			if (stroke != null) setStroke(px(1), stroke)
		}
		fun label(value: String, size: Float, color: Int, weight: String, fallback: Typeface) =
			TextView(activity).apply {
				text = value
				textSize = size
				setTextColor(color)
				typeface = ggSans(activity, weight) ?: fallback
			}
		fun button(value: String, background: Int, foreground: Int) =
			label(value, 16f, foreground, "Semibold", Typeface.DEFAULT_BOLD).apply {
				gravity = Gravity.CENTER
				minHeight = px(48)
				setPadding(px(16), 0, px(16), 0)
				this.background = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), shape(background, 999), null)
				isClickable = true
				isFocusable = true
			}

		val dialog = Dialog(activity)
		val column = LinearLayout(activity).apply {
			orientation = LinearLayout.VERTICAL
			setPadding(px(24), px(24), px(24), px(20))
			background = shape(p.surface, 16)
		}
		fun add(view: View, top: Int) = column.addView(
			view,
			LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
				.apply { topMargin = px(top) },
		)

		add(label(title, 20f, p.heading, "ExtraBold", Typeface.DEFAULT_BOLD).apply { gravity = Gravity.CENTER }, 0)
		add(
			label(message, 16f, p.muted, "Medium", Typeface.DEFAULT).apply {
				gravity = Gravity.CENTER
				setLineSpacing(px(2).toFloat(), 1f)
			},
			8,
		)

		val field = input?.let { spec ->
			spec.label?.let { add(label(it, 14f, p.text, "Semibold", Typeface.DEFAULT_BOLD), 20) }
			EditText(activity).apply {
				hint = spec.hint
				isSingleLine = true
				inputType = InputType.TYPE_CLASS_TEXT or
					if (spec.password) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
				textSize = 16f
				setTextColor(p.text)
				setHintTextColor(p.muted)
				typeface = ggSans(activity, "Medium") ?: Typeface.DEFAULT
				setPadding(px(14), px(12), px(14), px(12))
				background = shape(p.inputBackground, 12, p.inputBorder)
				setOnFocusChangeListener { _, focused ->
					background = shape(p.inputBackground, 12, if (focused) p.inputBorderActive else p.inputBorder)
				}
				add(this, if (spec.label != null) 8 else 20)
			}
		}

		val confirm = if (destructive) {
			button(action, p.criticalBackground, p.criticalText)
		} else {
			button(action, p.primaryBackground, p.primaryText)
		}
		val cancel = button("Cancel", p.secondaryBackground, p.secondaryText)
		add(confirm, 24)
		add(cancel, 8)

		fun typed() = field?.text?.toString()?.trim().orEmpty()
		fun allowed(): Boolean {
			val required = input?.required ?: return input == null || typed().isNotEmpty()
			return typed() == required
		}
		fun refresh() {
			val ok = allowed()
			confirm.isEnabled = ok
			confirm.alpha = if (ok) 1f else 0.5f
		}
		field?.addTextChangedListener(object : TextWatcher {
			override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
			override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
			override fun afterTextChanged(s: Editable?) = refresh()
		})
		refresh()

		confirm.setOnClickListener {
			if (!allowed()) return@setOnClickListener
			result.complete(typed())
			dialog.dismiss()
		}
		cancel.setOnClickListener {
			result.complete(null)
			dialog.dismiss()
		}
		dialog.setOnCancelListener { result.complete(null) }

		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
		dialog.setContentView(column)
		dialog.window?.apply {
			setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
			val width = activity.resources.displayMetrics.widthPixels - px(32)
			setLayout(minOf(width, px(420)), WindowManager.LayoutParams.WRAP_CONTENT)
			if (field != null) setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
		}
		dialog.show()
		field?.requestFocus()
	}
	return withTimeoutOrNull(timeoutMs) { result.await() }
}

/**
 * Resolves the typed key, or null on cancel / no activity within the timeout. An address that isn't
 * a known provider (or this device / home network) gets a warning: a lookalike host is the one way
 * left to get the key typed in for somewhere else.
 */
private suspend fun PluginScope.askForKey(endpoint: String): String? = discordDialog(
	title = "API key",
	message = "Only ever sent to ${hostOf(endpoint)}. Stored encrypted by Android's keystore; " +
		"no plugin can read it back, including this one's settings screen." +
		(if (hostOf(endpoint).lowercase() !in KNOWN_HOSTS && !isPrivateHost(hostOf(endpoint).lowercase()))
			"\n\n${hostOf(endpoint)} isn't a provider AI Core knows. Only continue if you typed this address yourself."
		else ""),
	action = "Save",
	input = DialogInput(hint = "sk-...", password = true),
	timeoutMs = 5 * 60_000L,
)?.ifEmpty { null }

private suspend fun PluginScope.confirm(
	title: String,
	message: String,
	action: String,
	destructive: Boolean = false,
): Boolean = discordDialog(title, message, action, destructive) != null

/**
 * A confirmation that has to be earned: [action] stays disabled until [word] is typed. For choices
 * where a reflexive tap would be a real mistake, not just an undo.
 */
private suspend fun PluginScope.confirmTyped(title: String, message: String, word: String, action: String): Boolean =
	discordDialog(
		title,
		message,
		action,
		destructive = true,
		input = DialogInput(label = "Type $word to confirm", required = word),
	) != null

// --- the plugin ----------------------------------------------------------------

@Suppress("UNUSED")
val aiCore = plugin {
	start {
		MinifiedTheme.finder = runCatching { dexFinder }.getOrNull()
		val id = manifest.id
		val mutex = Mutex()
		val vaultFile = File(storageDir, VAULT_FILE)
		val usageFile = File(storageDir, USAGE_FILE)

		var apiKey: String? = null
		var endpoint: String? = null
		var vaultError: String? = null
		// The model every request uses, set from AI Core's own settings page. Kept here rather than
		// taken from each request, so a caller can't switch to a pricier model.
		var model: String? = null

		// ## Only AI Core's own JS may call the methods that spend money or open dialogs
		//
		// The caller of a native method can't be identified, so AI Core's JS holds a session token and
		// sends it with every such call. The token is never returned to whoever asks for one: it is
		// pushed to the JS method AI Core registers (`<id>.session`). A plugin calling these methods
		// directly gets "session" back. Asking for a new token only replaces the old one; AI Core then
		// asks again and retries. Which plugins may use AI Core at all is decided in its JS
		// (`decorate`), from where Revenge says each one was installed from.
		var session: String? = null
		val random = java.security.SecureRandom()
		val host = this
		fun authorised(token: Any?): Boolean {
			val current = session ?: return false
			val given = token as? String ?: return false
			return java.security.MessageDigest.isEqual(current.toByteArray(), given.toByteArray())
		}
		fun refused(): String = JSONObject().put("ok", false).put("error", "session").toString()

		// Usage and the cap. Encrypted too -- not because they are secret, but so a plugin with
		// `fs` cannot simply rewrite the count to zero or the cap to a thousand.
		var cap = 40
		// No daily ceiling at all. Calls are still counted; only the check against `cap` is skipped.
		var unlimited = false
		var day = ""
		var calls = 0
		var promptTokens = 0L
		var completionTokens = 0L
		val byPlugin = mutableMapOf<String, Int>()
		// Set when the usage file exists but will not open. Fails closed: nothing calls out until
		// the user confirms a reset natively.
		var usageTampered = false

		// Local calendar day, matching the JS side. Not java.time: that needs API 26 and Discord runs on 24.
		fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

		fun rollDay() {
			val now = today()
			if (day != now) {
				day = now
				calls = 0
				promptTokens = 0
				completionTokens = 0
				byPlugin.clear()
			}
		}

		fun persistVault() {
			val key = apiKey
			val ep = endpoint
			if (key == null || ep == null) {
				vaultFile.delete()
				return
			}
			vaultFile.writeText(seal(JSONObject().put("key", key).put("endpoint", ep).toString()))
		}

		fun persistUsage() {
			val counts = JSONObject()
			byPlugin.forEach { (k, v) -> counts.put(k, v) }
			usageFile.writeText(
				seal(
					JSONObject()
						.put("cap", cap)
						.put("unlimited", unlimited)
						.put("day", day)
						.put("calls", calls)
						.put("promptTokens", promptTokens)
						.put("completionTokens", completionTokens)
						.put("byPlugin", counts)
						.put("model", model ?: JSONObject.NULL)
						.toString(),
				),
			)
		}

		fun load() {
			if (vaultFile.exists()) {
				val plain = open(vaultFile.readText())
				if (plain == null) {
					vaultError = "The stored key could not be opened (Android keystore reset, or the file was altered). Enter it again."
				} else {
					val obj = JSONObject(plain)
					apiKey = obj.optString("key").ifEmpty { null }
					endpoint = obj.optString("endpoint").ifEmpty { null }
				}
			}
			if (usageFile.exists()) {
				val plain = open(usageFile.readText())
				if (plain == null) {
					usageTampered = true
				} else {
					val obj = JSONObject(plain)
					cap = obj.optInt("cap", cap).coerceIn(0, MAX_CAP)
					unlimited = obj.optBoolean("unlimited", false)
					day = obj.optString("day")
					calls = obj.optInt("calls")
					promptTokens = obj.optLong("promptTokens")
					completionTokens = obj.optLong("completionTokens")
					obj.optJSONObject("byPlugin")?.let { counts ->
						counts.keys().forEach { k -> byPlugin[k] = counts.optInt(k) }
					}
					model = obj.optString("model").ifEmpty { null }
				}
			} else if (vaultFile.exists()) {
				// Written together, so a vault without usage means the usage file was deleted.
				usageTampered = true
			}
			rollDay()
		}

		fun status(): String {
			rollDay()
			val counts = JSONObject()
			byPlugin.forEach { (k, v) -> counts.put(k, v) }
			return JSONObject()
				.put("configured", apiKey != null && endpoint != null)
				.put("endpoint", endpoint ?: JSONObject.NULL)
				.put("vaultError", vaultError ?: JSONObject.NULL)
				.put("usageTampered", usageTampered)
				.put("migrated", vaultFile.exists() || usageFile.exists())
				.put("cap", cap)
				.put("unlimited", unlimited)
				.put("day", day)
				.put("calls", calls)
				// JSON has no Infinity, so an unlimited day reports the cap's remainder and the JS
				// side reads `unlimited` first. Tampering still fails closed either way.
				.put("remaining", if (usageTampered) 0 else (cap - calls).coerceAtLeast(0))
				.put("promptTokens", promptTokens)
				.put("completionTokens", completionTokens)
				.put("byPlugin", counts)
				.put("model", model ?: JSONObject.NULL)
				.toString()
		}

		/** A status reply carrying "session": the caller didn't send AI Core's token. */
		fun refusedStatus(): String = JSONObject(status()).put("error", "session").toString()

		runCatching { load() }.onFailure { error ->
			vaultError = "Could not read AI Core's vault: ${error.javaClass.simpleName}"
			log.e("vault load failed", error)
		}

		registerNativeAsyncMethod("$id.status") { _ -> mutex.withLock { status() } }

		// A fresh token, pushed to AI Core's JS; never returned. The old one stops working.
		registerNativeAsyncMethod("$id.session") { _ ->
			val bytes = ByteArray(32).also(random::nextBytes)
			val token = bytes.joinToString("") { "%02x".format(it) }
			mutex.withLock { session = token }
			runCatching { host.callJSMethod("$id.session", listOf(token)) }
				.onFailure { log.e("could not hand AI Core its session: ${it.javaClass.simpleName}") }
			true
		}

		// The one way a key gets in. Nothing about the key crosses back to JS.
		registerNativeAsyncMethod("$id.promptForKey") { args ->
			if (!authorised(args.getOrNull(0))) return@registerNativeAsyncMethod mutex.withLock { refusedStatus() }
			val requested = args.getOrNull(1) as? String ?: return@registerNativeAsyncMethod status()
			val ep = normalizeEndpoint(requested)
				?: return@registerNativeAsyncMethod JSONObject(mutex.withLock { status() })
					.put("error", "The base URL must be https://, or http:// to this device or your local network.")
					.toString()
			val key = askForKey(ep) ?: return@registerNativeAsyncMethod mutex.withLock { status() }
			mutex.withLock {
				apiKey = key
				endpoint = ep
				vaultError = null
				persistVault()
				persistUsage()
				status()
			}
		}

		// Asks first, natively: a plugin could otherwise wipe the key without a word.
		registerNativeAsyncMethod("$id.clearKey") { args ->
			if (!authorised(args.getOrNull(0))) return@registerNativeAsyncMethod mutex.withLock { refusedStatus() }
			val ok = confirm(
				"Remove the API key?",
				"Every plugin using AI Core stops working until you enter a key again.",
				"Remove",
				destructive = true,
			)
			mutex.withLock {
				if (ok) {
					apiKey = null
					endpoint = null
					vaultError = null
					persistVault()
				}
				status()
			}
		}

		// The model every request uses. AI Core's settings page sets it; nothing else can.
		registerNativeAsyncMethod("$id.setModel") { args ->
			if (!authorised(args.getOrNull(0))) return@registerNativeAsyncMethod mutex.withLock { refusedStatus() }
			val wanted = (args.getOrNull(1) as? String)?.trim()?.take(200)?.ifEmpty { null }
			mutex.withLock {
				model = wanted
				persistUsage()
				status()
			}
		}

		// One-time move of a key from the old plain-text jsonStorage. Refused once the vault or the
		// usage file has ever existed, so it cannot be used later to swap in someone else's key.
		registerNativeAsyncMethod("$id.importLegacy") { args ->
			// Session-gated: before any key is set, another plugin could otherwise bind the vault to
			// its own key and server, and every plugin's prompts would go there.
			if (!authorised(args.getOrNull(0))) return@registerNativeAsyncMethod false
			val key = (args.getOrNull(1) as? String)?.trim().orEmpty()
			val ep = normalizeEndpoint(args.getOrNull(2) as? String ?: "")
			val legacyCap = (args.getOrNull(3) as? Number)?.toInt()
			mutex.withLock {
				if (vaultFile.exists() || usageFile.exists()) return@withLock false
				if (legacyCap != null) cap = legacyCap.coerceIn(0, MAX_CAP)
				if (key.isNotEmpty() && ep != null) {
					apiKey = key
					endpoint = ep
					persistVault()
				}
				persistUsage()
				true
			}
		}

		// Lowering is always allowed. Raising asks natively, so another plugin cannot quietly
		// give itself a bigger budget.
		registerNativeAsyncMethod("$id.setCap") { args ->
			if (!authorised(args.getOrNull(0))) return@registerNativeAsyncMethod mutex.withLock { refusedStatus() }
			val wanted = ((args.getOrNull(1) as? Number)?.toInt() ?: return@registerNativeAsyncMethod status())
				.coerceIn(0, MAX_CAP)
			val current = mutex.withLock { cap }
			if (wanted > current &&
				!confirm("Raise the AI Core cap?", "Allow up to $wanted calls a day, from $current. Every plugin using AI Core shares this.", "Raise")
			) {
				return@registerNativeAsyncMethod mutex.withLock { status() }
			}
			mutex.withLock {
				cap = wanted
				persistUsage()
				status()
			}
		}

		// Turning the ceiling off is the one change here that can cost real money with no upper
		// bound, so it needs the word typed, not a tap. Turning it back on applies at once.
		registerNativeAsyncMethod("$id.setUnlimited") { args ->
			if (!authorised(args.getOrNull(0))) return@registerNativeAsyncMethod mutex.withLock { refusedStatus() }
			val wanted = args.getOrNull(1) as? Boolean ?: return@registerNativeAsyncMethod mutex.withLock { status() }
			if (wanted && !mutex.withLock { unlimited } &&
				!confirmTyped(
					"Remove the AI Core daily cap?",
					"Every plugin using AI Core will be able to make as many calls as it likes, every day. " +
						"Each one is billed to your key. Nothing here will stop a plugin stuck in a loop; " +
						"only a spending limit set with your provider will.",
					"UNLIMITED",
					"Remove cap",
				)
			) {
				return@registerNativeAsyncMethod mutex.withLock { status() }
			}
			mutex.withLock {
				unlimited = wanted
				persistUsage()
				status()
			}
		}

		registerNativeAsyncMethod("$id.resetUsage") { args ->
			if (!authorised(args.getOrNull(0))) return@registerNativeAsyncMethod mutex.withLock { refusedStatus() }
			val ok = confirm(
				"Reset today's AI Core count?",
				"The cap starts again from zero. This does not refund anything already spent with the provider.",
				"Reset",
				destructive = true,
			)
			mutex.withLock {
				if (ok) {
					day = today()
					calls = 0
					promptTokens = 0
					completionTokens = 0
					byPlugin.clear()
					usageTampered = false
					persistUsage()
				}
				status()
			}
		}

		/** The Messages API version of the request below, for a key bound to Anthropic. */
		suspend fun anthropicRequest(key: String, ep: String, body: JSONObject, timeout: Int): String {
			val payload = anthropicPayload(body)
			val base = ep.trimEnd('/').removeSuffix("/v1")
			return runCatching {
				val connection = URL("$base/v1/messages").openConnection() as HttpURLConnection
				try {
					connection.instanceFollowRedirects = false
					connection.requestMethod = "POST"
					connection.connectTimeout = timeout
					connection.readTimeout = timeout
					connection.doOutput = true
					connection.setRequestProperty("Content-Type", "application/json")
					connection.setRequestProperty("x-api-key", key)
					connection.setRequestProperty("anthropic-version", "2023-06-01")
					if (payload.has("fallbacks")) connection.setRequestProperty("anthropic-beta", FALLBACK_BETA)
					connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

					val code = connection.responseCode
					if (code !in 200..299) {
						val err = connection.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
						log.e("Anthropic HTTP $code: $err")
						return@runCatching JSONObject().put("ok", false).put("status", code).put("error", "http").put("details", err).toString()
					}
					val response = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
					val usage = response.optJSONObject("usage")
					val pt = usage?.optLong("input_tokens") ?: 0L
					val ct = usage?.optLong("output_tokens") ?: 0L
					mutex.withLock {
						rollDay()
						promptTokens += pt
						completionTokens += ct
						persistUsage()
					}
					// A decline (even after the fallback) is HTTP 200 with stop_reason "refusal";
					// check that before reading content. Only text blocks are the answer: thinking
					// and fallback blocks are skipped.
					if (response.optString("stop_reason") == "refusal") {
						return@runCatching JSONObject().put("ok", false).put("error", "refusal")
							.put("promptTokens", pt).put("completionTokens", ct).toString()
					}
					val blocks = response.optJSONArray("content") ?: JSONArray()
					val text = StringBuilder()
					for (i in 0 until blocks.length()) {
						val block = blocks.optJSONObject(i) ?: continue
						if (block.optString("type") == "text") text.append(block.optString("text"))
					}
					val content = text.toString().takeIf { it.isNotEmpty() }
					JSONObject()
						.put("ok", content != null)
						.put("content", content ?: JSONObject.NULL)
						.put("promptTokens", pt)
						.put("completionTokens", ct)
						.toString()
				} finally {
					connection.disconnect()
				}
			}.getOrElse { error ->
				// Never the message: an exception from the HTTP stack can quote the request.
				JSONObject().put("ok", false).put("error", error.javaClass.simpleName).toString()
			}
		}

		/**
		 * request(pluginId, body, timeoutMs) -> {ok, status?, error?, content?, promptTokens, completionTokens}
		 *
		 * Only whitelisted body fields are forwarded, so a caller cannot smuggle in anything the
		 * provider would act on beyond an ordinary completion.
		 */
		registerNativeAsyncMethod("$id.request") { args ->
			if (!authorised(args.getOrNull(0))) return@registerNativeAsyncMethod refused()
			val pluginId = args.getOrNull(1) as? String ?: "unknown"
			val body = JSONObject((args.getOrNull(2) as? Map<*, *>) ?: emptyMap<String, Any?>())
			val timeout = ((args.getOrNull(3) as? Number)?.toInt() ?: 4000).coerceIn(500, 120_000)

			// The ceilings, before anything is counted or sent.
			val messages = body.optJSONArray("messages") ?: JSONArray()
			if (messages.length() > MAX_MESSAGES || messages.toString().length > MAX_PROMPT_CHARS) {
				return@registerNativeAsyncMethod JSONObject().put("ok", false).put("error", "too-large").toString()
			}
			body.put("max_tokens", body.optInt("max_tokens", 256).coerceIn(1, MAX_OUTPUT_TOKENS))
			// The model the user chose on AI Core's page, not the caller's. Until one has been saved
			// (just updated from a version without this), the request's own.
			mutex.withLock { model }?.let { body.put("model", it) }

			val (key, ep) = mutex.withLock {
				rollDay()
				val k = apiKey
				val e = endpoint
				when {
					k == null || e == null -> return@registerNativeAsyncMethod JSONObject().put("ok", false).put("error", "no-key").toString()
					usageTampered -> return@registerNativeAsyncMethod JSONObject().put("ok", false).put("error", "usage-tampered").toString()
					!unlimited && calls >= cap -> return@registerNativeAsyncMethod JSONObject().put("ok", false).put("error", "cap").toString()
				}
				// Counted up front, so parallel requests cannot all slip in under the last call.
				calls++
				byPlugin[pluginId] = (byPlugin[pluginId] ?: 0) + 1
				persistUsage()
				k to e
			}

			if (isAnthropic(ep)) return@registerNativeAsyncMethod anthropicRequest(key, ep, body, timeout)

			val payload = JSONObject()
			for (field in listOf("model", "temperature", "max_tokens", "response_format", "messages")) {
				if (body.has(field)) payload.put(field, body.get(field))
			}
			adaptForOpenAiOrGroq(payload, ep)
			if (isNvidia(ep)) adaptForNvidia(payload)

			runCatching {
				val connection = URL("$ep/chat/completions").openConnection() as HttpURLConnection
				try {
					connection.instanceFollowRedirects = false
					connection.requestMethod = "POST"
					connection.connectTimeout = timeout
					connection.readTimeout = timeout
					connection.doOutput = true
					connection.setRequestProperty("Content-Type", "application/json")
					connection.setRequestProperty("Authorization", "Bearer $key")
					connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

					val code = connection.responseCode
					if (code !in 200..299) {
						val err = connection.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
						log.e("Provider HTTP $code: $err")
						return@runCatching JSONObject().put("ok", false).put("status", code).put("error", "http").put("details", err).toString()
					}
					val response = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
					val usage = response.optJSONObject("usage")
					val pt = usage?.optLong("prompt_tokens") ?: 0L
					val ct = usage?.optLong("completion_tokens") ?: 0L
					mutex.withLock {
						rollDay()
						promptTokens += pt
						completionTokens += ct
						persistUsage()
					}
					val raw = response.optJSONArray("choices")
						?.optJSONObject(0)
						?.optJSONObject("message")
						?.opt("content") as? String
					val content = raw?.replace(THINK_BLOCK, "")?.takeIf { it.isNotBlank() }
					if (content == null) {
						val finish = response.optJSONArray("choices")?.optJSONObject(0)?.optString("finish_reason")
						log.e("Provider sent no answer (finish_reason=$finish, $ct output tokens)" + if (finish == "length") ": the model used the whole allowance before answering" else "")
					}
					JSONObject()
						.put("ok", content != null)
						.put("content", content ?: JSONObject.NULL)
						.put("promptTokens", pt)
						.put("completionTokens", ct)
						.toString()
				} finally {
					connection.disconnect()
				}
			}.getOrElse { error ->
				// Never the message: an exception from the HTTP stack can quote the request.
				JSONObject().put("ok", false).put("error", error.javaClass.simpleName).toString()
			}
		}

		/** One POST with the key; the answer as JSON, or the HTTP failure. */
		fun postWithKey(url: String, key: String, contentType: String, timeout: Int, body: (java.io.OutputStream) -> Unit): Pair<Int, String> {
			val connection = URL(url).openConnection() as HttpURLConnection
			try {
				connection.instanceFollowRedirects = false
				connection.requestMethod = "POST"
				connection.connectTimeout = timeout
				connection.readTimeout = timeout
				connection.doOutput = true
				connection.setRequestProperty("Content-Type", contentType)
				connection.setRequestProperty("Authorization", "Bearer $key")
				connection.outputStream.use(body)
				val code = connection.responseCode
				val text = (if (code in 200..299) connection.inputStream else connection.errorStream)
					?.bufferedReader()?.use { it.readText() } ?: ""
				return code to text
			} finally {
				connection.disconnect()
			}
		}

		/**
		 * transcribe(pluginId, url, language?, timeoutMs) -> {ok, text?, error?, status?, details?}
		 *
		 * Speech to text for a Discord attachment ([url] must be one: Audio.allowed), with the key's
		 * own provider, counted as one call:
		 * - OpenAI, Groq and custom/self-hosted endpoints: `POST /audio/transcriptions` with the file
		 *   as it is (gpt-4o-mini-transcribe, whisper-large-v3-turbo, or whisper-1 elsewhere).
		 * - OpenRouter: chat with `input_audio` (16 kHz WAV, two minutes per request) on Gemini Flash.
		 * - Anthropic, DeepSeek and NVIDIA's API take no audio: `unsupported`, nothing counted.
		 */
		registerNativeAsyncMethod("$id.transcribe") { args ->
			if (!authorised(args.getOrNull(0))) return@registerNativeAsyncMethod refused()
			val pluginId = args.getOrNull(1) as? String ?: "unknown"
			val url = args.getOrNull(2) as? String
			val language = (args.getOrNull(3) as? String)?.trim()?.takeIf { it.isNotEmpty() && it.length <= 40 }
			val timeout = ((args.getOrNull(4) as? Number)?.toInt() ?: 120_000).coerceIn(5_000, 300_000)
			fun fail(error: String, details: String? = null, status: Int? = null) = JSONObject()
				.put("ok", false).put("error", error).put("details", details ?: JSONObject.NULL).put("status", status ?: JSONObject.NULL).toString()
			if (url == null || !Audio.allowed(url)) return@registerNativeAsyncMethod fail("bad-url")

			val (key, ep) = mutex.withLock {
				rollDay()
				val k = apiKey
				val e = endpoint
				when {
					k == null || e == null -> return@registerNativeAsyncMethod fail("no-key")
					usageTampered -> return@registerNativeAsyncMethod fail("usage-tampered")
					isAnthropic(e) || isNvidia(e) || hostOf(e).equals("api.deepseek.com", ignoreCase = true) ->
						return@registerNativeAsyncMethod fail("unsupported")
					!unlimited && calls >= cap -> return@registerNativeAsyncMethod fail("cap")
				}
				calls++
				byPlugin[pluginId] = (byPlugin[pluginId] ?: 0) + 1
				persistUsage()
				k to e
			}

			val work = File(storageDir, "audio/${java.util.UUID.randomUUID()}")
			try {
				withContext(Dispatchers.IO) {
					val input = File(work, "voice.ogg")
					Audio.download(url, input)
					val host = hostOf(ep).lowercase()
					if (host == "openrouter.ai") {
						val pieces = Audio.toWavPieces(input, File(work, "pieces"), 120)
						val ask = "Transcribe this audio word for word" +
							(if (language != null) ", in $language" else ", in the language that is spoken") +
							". Write only the spoken words, with normal punctuation. No notes, no timestamps, no translation."
						val parts = pieces.files.map { piece ->
							val audio = JSONObject()
								.put("type", "input_audio")
								.put("input_audio", JSONObject().put("data", Base64.encodeToString(piece.readBytes(), Base64.NO_WRAP)).put("format", "wav"))
							val payload = JSONObject()
								.put("model", "google/gemini-2.5-flash")
								.put("temperature", 0)
								.put("max_tokens", 2048)
								.put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", JSONArray().put(JSONObject().put("type", "text").put("text", ask)).put(audio))))
							val (code, text) = postWithKey("$ep/chat/completions", key, "application/json", timeout) {
								it.write(payload.toString().toByteArray(Charsets.UTF_8))
							}
							if (code !in 200..299) return@withContext fail("http", text.take(500), code)
							(JSONObject(text).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.opt("content") as? String)
								?.replace(THINK_BLOCK, "")?.trim().orEmpty()
						}
						JSONObject().put("ok", true).put("text", parts.joinToString(" ").trim()).toString()
					} else {
						val model = when (host) {
							"api.openai.com" -> "gpt-4o-mini-transcribe"
							"api.groq.com" -> "whisper-large-v3-turbo"
							else -> "whisper-1"
						}
						val boundary = "aicore${System.nanoTime()}"
						val (code, text) = postWithKey("$ep/audio/transcriptions", key, "multipart/form-data; boundary=$boundary", timeout) { out ->
							fun field(name: String, value: String) {
								out.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray(Charsets.UTF_8))
							}
							field("model", model)
							field("response_format", "json")
							// The API wants an ISO code; a word ("Spanish") is left to its own detection.
							if (language != null && Regex("^[a-z]{2}$").matches(language)) field("language", language)
							out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"voice-message.ogg\"\r\nContent-Type: audio/ogg\r\n\r\n".toByteArray(Charsets.UTF_8))
							input.inputStream().use { it.copyTo(out) }
							out.write("\r\n--$boundary--\r\n".toByteArray(Charsets.UTF_8))
						}
						if (code !in 200..299) return@withContext fail("http", text.take(500), code)
						JSONObject().put("ok", true).put("text", JSONObject(text).optString("text").trim()).toString()
					}
				}
			} catch (error: Throwable) {
				// Never the message of an HTTP failure: it can quote the request. Our own are safe.
				fail("failed", if (error is IllegalStateException || error is IllegalArgumentException) error.message else error.javaClass.simpleName)
			} finally {
				work.deleteRecursively()
			}
		}

		/** One GET with the key, to a fixed URL. Null on anything but a 2xx JSON answer. */
		fun getJson(url: String, key: String): JSONObject? = runCatching {
			val connection = URL(url).openConnection() as HttpURLConnection
			try {
				connection.instanceFollowRedirects = false
				connection.requestMethod = "GET"
				connection.connectTimeout = 10_000
				connection.readTimeout = 10_000
				connection.setRequestProperty("Accept", "application/json")
				connection.setRequestProperty("Authorization", "Bearer $key")
				if (connection.responseCode !in 200..299) return@runCatching null
				JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
			} finally {
				connection.disconnect()
			}
		}.getOrNull()

		/**
		 * balance() -> {ok, supported, provider?, currency?, total?, granted?, toppedUp?, keyLimit?, keyRemaining?, error?}
		 *
		 * The money left on the key, for the two providers that report it to an ordinary API key.
		 * OpenAI and Anthropic only expose spend through admin keys, and never a balance, so they
		 * answer `supported: false`. The URL is fixed per provider and only used when the key is
		 * bound to that provider's host, so this can't send the key anywhere new. Not counted
		 * against the daily cap: it is not a model call.
		 *
		 * - DeepSeek: `GET /user/balance` -> `balance_infos[0]` (strings, e.g. "4.21", in USD or CNY).
		 * - OpenRouter: `GET /api/v1/credits` (account: total bought minus used) and `GET /api/v1/key`
		 *   (this key's own limit, when one was set). Either may be refused; whichever answers is shown.
		 */
		registerNativeAsyncMethod("$id.balance") { args ->
			if (!authorised(args.getOrNull(0))) return@registerNativeAsyncMethod JSONObject().put("ok", false).put("supported", false).put("error", "session").toString()
			val (key, ep) = mutex.withLock { apiKey to endpoint }
			if (key == null || ep == null) {
				return@registerNativeAsyncMethod JSONObject().put("ok", false).put("supported", false).put("error", "no-key").toString()
			}
			val host = hostOf(ep).lowercase()
			when (host) {
				"api.deepseek.com" -> {
					val info = getJson("https://api.deepseek.com/user/balance", key)
						?.optJSONArray("balance_infos")?.optJSONObject(0)
						?: return@registerNativeAsyncMethod JSONObject().put("ok", false).put("supported", true)
							.put("provider", "deepseek").put("error", "unavailable").toString()
					JSONObject()
						.put("ok", true)
						.put("supported", true)
						.put("provider", "deepseek")
						.put("currency", info.optString("currency", "USD"))
						.put("total", info.optString("total_balance").toDoubleOrNull() ?: JSONObject.NULL)
						.put("granted", info.optString("granted_balance").toDoubleOrNull() ?: JSONObject.NULL)
						.put("toppedUp", info.optString("topped_up_balance").toDoubleOrNull() ?: JSONObject.NULL)
						.toString()
				}
				"openrouter.ai" -> {
					val credits = getJson("https://openrouter.ai/api/v1/credits", key)?.optJSONObject("data")
					val keyInfo = getJson("https://openrouter.ai/api/v1/key", key)?.optJSONObject("data")
					val out = JSONObject().put("supported", true).put("provider", "openrouter").put("currency", "USD")
					if (credits != null && credits.has("total_credits")) {
						out.put("total", credits.optDouble("total_credits", 0.0) - credits.optDouble("total_usage", 0.0))
					}
					if (keyInfo != null) {
						if (!keyInfo.isNull("limit")) out.put("keyLimit", keyInfo.optDouble("limit"))
						if (!keyInfo.isNull("limit_remaining")) out.put("keyRemaining", keyInfo.optDouble("limit_remaining"))
					}
					out.put("ok", out.has("total") || out.has("keyRemaining") || keyInfo != null)
					if (!out.getBoolean("ok")) out.put("error", "unavailable")
					out.toString()
				}
				else -> JSONObject().put("ok", false).put("supported", false).toString()
			}
		}

		log.i("vault ready (${if (apiKey != null) "key set for ${hostOf(endpoint ?: "")}" else "no key"})")
	}

	stop {
		log.i("Unloaded ${manifest.id}")
	}
}
